import styles from './Home.module.css';

function Home() {
    return <div className={styles.home}>
        <h1>Flipazon</h1>
        <h3>Shop with us and enjoy the convenience of online shopping.</h3>
    </div>
}

export default Home;