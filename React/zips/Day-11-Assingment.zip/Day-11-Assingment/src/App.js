import './App.css';
import React from 'react';
import Stories from './pages/Stories';



class App extends React.Component{


  render(){
    return <Stories></Stories>
  }
}

export default App;
