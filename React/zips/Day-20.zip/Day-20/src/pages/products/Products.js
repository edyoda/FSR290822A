import CardGrid from "../../card/CardGrid";

function Product() {
  

  return <CardGrid showPrice={true} addToCart={() => {}}></CardGrid>;
}

export default Product;
